// bitset.h
// Řešení IJC-DU1, příklad a), 20.3.2022
// Autor: Tomas Suda, FIT
// Přeloženo: gcc 11.4.0
// pracujem s errorh a error.c

#ifndef BITSET_H
#define BITSET_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include "error.h"

//#define USE_INLINE

//
//#define _ON_STACK
#define SIZE_OF_RESULTS (10)
#define MODUL_NAME "bitset"


 typedef unsigned long bitset_t;
 typedef unsigned long bitset_index_t;

//  itbset_create(jmeno_pole,velikost)
    //    definuje a _nuluje_ proměnnou jmeno_pole
    //    (POZOR: opravdu musí _INICIALIZOVAT_ pole bez ohledu na
    //    to, zda je pole statické nebo automatické/lokální!
    //    Vyzkoušejte obě varianty, v programu použijte _lokální_ pole.)
    //    Použijte  static_assert  pro kontrolu velikosti pole.
    //        bitset_create(q,-100);       // chyba při překladu

 

// void error_exit(unsigned long index, unsigned long mez){
//     fprintf(stderr, "bitset_getbit: Index %lu out of range 0..%lu\n", index, mez);return;
//     }
  #ifdef USE_INLINE

     inline  bitset_t* bitset_create (bitset_t *jmeno_pole, unsigned long velikost){assert(velikost > 0); return jmeno_pole;}
  #else
   #define bitset_create(jmeno_pole, velikost) do { \
    static_assert( velkost > 0); \
    bitset_index_t jmeno_pole[velikost]; \
} while(0)

  #endif
    
    //  bitset_alloc(jmeno_pole,velikost)
    //    definuje proměnnou jmeno_pole tak, aby byla kompatibilní s polem
    //    vytvořeným pomocí bitset_create, ale pole bude alokováno dynamicky.
    //    Použijte  assert  pro kontrolu velikosti pole.
    //    Pokud alokace selže, ukončete program s chybovým hlášením:
    //    "bitset_alloc: Chyba alokace paměti"
  #ifdef USE_INLINE

     inline void bitset_alloc(bitset_t **jmeno_pole, unsigned long velikost) {
    assert(velikost > 0); 
    *jmeno_pole = (bitset_t *) malloc(velikost*sizeof(unsigned long));
    if (*jmeno_pole == NULL) { 
            error_exit("bitset_alloc: Chyba alokace paměti");
        } 
    }
  #else
   #define bitset_alloc(jmeno_pole, velikost) \
    do { \
      assert(velikost > 0); \
        *jmeno_pole = (bitset_t *) malloc(velikost*sizeof(unsigned long)); \
        if (*jmeno_pole == NULL) { \
            error_exit("bitset_alloc: Chyba alokace paměti"); \
        } \
    } while(0)

  #endif

    //    uvolní paměť dynamicky (pomocí bitset_alloc) alokovaného pole

  #ifdef USE_INLINE

     inline void  bitset_free(bitset_t *jmeno_pole) {free(jmeno_pole);jmeno_pole=NULL;}
  #else
    #define bitset_free(jmeno_pole) {free(jmeno_pole);jmeno_pole=NULL;}
  #endif

    //    vrátí deklarovanou velikost pole v bitech (uloženou v poli)
 extern unsigned long pole_indexov_size;
 #ifdef USE_INLINE

     inline bitset_t bitset_size(bitset_t jmeno_pole) {return jmeno_pole;}
  #else
    #define bitset_size(jmeno_pole) jmeno_pole
  #endif

    //    vynuluje(false) nebo nastaví na 1(true) celý obsah pole
#ifdef USE_INLINE
     inline void bitset_fill(bitset_t *jmeno_pole, bool bool_výraz) {bitset_t ii;for (ii = 1L; ii< bitset_size(pole_indexov_size/8);ii++){jmeno_pole[ii] = (bool_výraz==true)? (unsigned long)(-1L): 0L ;};jmeno_pole[0] = ii*sizeof(long)*8;}
  #else
    #define bitset_fill(jmeno_pole,bool_výraz) bitset_t ii;for(ii = 1L; ii< bitset_size(pole_indexov_size/8);ii++){jmeno_pole[ii] = (bool_výraz==true)? (unsigned long)(-1L): 0L;};jmeno_pole[0] = ii*sizeof(long)*8;

  #endif

    //  bitset_setbit(jmeno_pole,index,bool_výraz)
    //    nastaví zadaný bit v poli na hodnotu zadanou výrazem
    //    (nulový výraz == false == bit 0, jinak bit 1)
#ifdef USE_INLINE

     inline void bitset_setbit(bitset_t *jmeno_pole,unsigned long index,bool bool_výraz) { if(index>jmeno_pole[0])error_exit("Bitset_setbit:index overflow (max=%lu, required=%lu\n",jmeno_pole[0],index);if(bool_výraz==true){ jmeno_pole[((index/sizeof(long))/8)+1]|=(1l<<((index%(sizeof(long)*8)))); }else {jmeno_pole[((index/sizeof(long))/8)+1]&=~(1l<<((index%(sizeof(long)*8))));}}
  #else
    #define bitset_setbit(jmeno_pole,index,bool_výraz) if(index>jmeno_pole[0])error_exit("Bitset_setbit:index overflow (max=%lu, required=%lu\n",jmeno_pole[0],index);if(bool_výraz==true){ jmeno_pole[((index/sizeof(long))/8)+1]|=(1l<<((index%(sizeof(long)*8)))); }else {jmeno_pole[((index/sizeof(long))/8)+1]&=~(1l<<((index%(sizeof(long)*8))));}
  #endif

    //  bitset_getbit(jmeno_pole,index)
    //    získá hodnotu zadaného bitu, vrací hodnotu 0 nebo 1
    #ifdef USE_INLINE

     inline bool bitset_getbit(bitset_t *jmeno_pole,unsigned long index) {if(index>jmeno_pole[0])error_exit("Bitset_getbit:index overflow (max=%lu, required=%lu\n",jmeno_pole[0],index);if ((jmeno_pole[((index/sizeof(long))/8)+1] & (1l << ((index % (sizeof(long) * 8))))) == 0L) {return false;} else {return true;}}
    #else
    #define bitset_getbit(jmeno_pole,index) if(index>jmeno_pole[0])error_exit("Bitset_getbit:index overflow (max=%lu, required=%lu\n",jmeno_pole[0],index);((getbit_val = jmeno_pole[((index/sizeof(long))/8)+1] & (1l << ((index % (sizeof(long) * 8))))) == 0L)?false:true
    #endif 
    

//    Kontrolujte meze polí. V případě chyby volejte funkci

//      error_exit("bitset_getbit: Index %lu mimo rozsah 0..%lu",
//                (unsigned long)index, (unsigned long)mez).              
    // #ifdef USE_INLINE
    //  inline void error_exit(unsigned long index, unsigned long mez){fprintf(stderr, "bitset_getbit: Index %lu out of range 0..%lu\n", index, mez);return;}
    // #else
    //     #define error_exit(index,mez) fprintf(stderr, "bitset_getbit: Index %lu out of range 0..%lu\n", index, mez);
    // #endif

unsigned long * prime(void);
#endif       