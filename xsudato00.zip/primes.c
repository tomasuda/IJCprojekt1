// primes.c
// Řešení IJC-DU1, příklad a), 20.3.2022
// Autor: Tomas Suda, FIT
// Přeloženo: gcc 11.4.0
// pracujem s errorh a error.c
#include "bitset.h"
#include <time.h>
#ifdef USE_INLINE
#include "error.h"

extern inline void bitset_alloc (bitset_t **p, unsigned long s);
extern inline void bitset_free(bitset_t *p);
extern inline void bitset_fill(bitset_t *p, bool vyraz);
extern  inline void bitset_setbit(bitset_t *p,unsigned long index,bool vyraz);
extern inline bool bitset_getbit(bitset_t *p,unsigned long index);
extern inline  bitset_t* bitset_create (bitset_t *p, unsigned long s);
extern  inline bitset_t bitset_size(bitset_t p);
#else
#endif
#define MYNUM (666000000UL)
//#define MYNUM (65)
unsigned long pole_indexov_size =(unsigned long) (((MYNUM/sizeof(unsigned long)))+sizeof(unsigned long));
unsigned long vysledky[SIZE_OF_RESULTS];

unsigned long* prime() {
    #ifdef _ON_STACK 
        #ifdef USE_INLINE  
                bitset_index_t local_pole_indexov[pole_indexov_size/8];
                
                bitset_t* pole_indexov = bitset_create(local_pole_indexov,pole_indexov_size/8);  
                
        #else
          
                bitset_t* pole_indexov; 
                
                bitset_create(local_pole_indexov,(pole_indexov_size/8));   
                
                pole_indexov = local_pole_indexov;            
        #endif
    #else
        bitset_t* pole_indexov;  
        bitset_alloc(&pole_indexov,pole_indexov_size/8);

    #endif
      bitset_index_t i,j;
       bitset_fill(pole_indexov, false);

     // Eratosthenovo sito
     for (i = 2; i <= sqrt(MYNUM); i++) {
        #ifdef USE_INLINE

            if (bitset_getbit(pole_indexov,i) == true){
        #else
        bool getbit_val;
            bitset_getbit(pole_indexov,i);
            if (getbit_val == true){
        #endif

            continue;
         }
         for (j = 2 * i; j <= MYNUM; j += i){
             bitset_setbit(pole_indexov,j,true);

         }
     }
     // ukladanie prvocisliel do pola prvočísel
      int k=SIZE_OF_RESULTS;
     for (i = MYNUM; i > 2; i--) {
       #ifdef USE_INLINE

            if (bitset_getbit(pole_indexov,i) == false){
        #else
        bool getbit_val;
            bitset_getbit(pole_indexov,i);
            if (getbit_val == false){
        #endif

        vysledky[--k] = i;
       if(k==0)break;
        }
     }
     
    #ifdef _ON_STACK    
    #else
        bitset_free(pole_indexov);
    #endif
    return vysledky;
}

int main(){
    // na zistenie casu
    clock_t start=clock();
    unsigned long *vysledky = prime();
    for(int i=0;i<SIZE_OF_RESULTS;i++)
        printf("%ld\n", vysledky[i]);
   fprintf(stderr, "Time=%.3g\n", (double)(clock()-start)/CLOCKS_PER_SEC);
   
    
 }