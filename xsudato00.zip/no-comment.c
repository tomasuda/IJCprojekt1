// no-comment.c
// Řešení IJC-DU1, příklad b) 20.3.2022
// Autor: Tomas Suda, FIT
// Přeloženo: gcc 11.4.0
// pracujem s error.c a error.h
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "error.h"
/*nastavenie priznakov na false 
predpokladam ze program bude mat aj nejake ine znaky ako 
komenty*/
bool Flag_L = false;// priznak lomitkoveho komentu //
bool pomocny_l=false;// pomocny priznaklomitkoveho komentu //
bool Flag_H = false;// priznak priznak klasickeho C komentu /**/
bool pomocna_h =false;// pomocny priznak klasickeho C komentu /**/
bool Flag_S = false;// priznak pre znak \ sluzi na pokracovanie // komentu na dalsi riadok
bool Flag_U = false;// priznak priznak ""
bool Flag_A = false;// priznak priznak ''
bool Flag_NORMAL =false;// priznak vsetkyvh inych znakou

// funkcia vybera znaky zo suboru a pokial niesu nastavene priznaky komentou  pridava ich na stdout

int mazac(FILE *file) {
    int ch;

    while ((ch = fgetc(file)) != EOF) {
        if( (Flag_U==true) &&(ch!='"')){ //znaky " sa musia zobrazovak aj ked su (/ * \ ' ")
            putchar(ch);
        }

        else if ( (Flag_A==true) && (ch!='\'')){//znaky " sa musia zobrazovak aj ked su (/ * \ ' ")
            putchar(ch);
        }

       else if ((ch == '\n') && (Flag_S==false)&& (Flag_H==false)) { // priznak lomitka sa nesnie zrusit
            putchar(' ');
            Flag_L = false;
        }
       
      
        switch (ch) {
            case '/': // vsetko do konca riadka sa musi ignorovat
                if ((Flag_U == false) && (Flag_A==false)){
                    
                    if((Flag_H==false)&&(pomocny_l==true)) {Flag_L = true; break;}

                    else if (pomocna_h==true){ 
                        Flag_H=false;
                        pomocna_h=false;
                        pomocny_l=false;
                        break;
                        }

                   pomocny_l=true;
                   break;
                }
                else {
                pomocny_l=true;}

                Flag_NORMAL =false;
                break;
            case '*': // vestko medzi /* a */ sa musi ignorovat
              if ((Flag_U==false) && (Flag_A==false)){
                if ((pomocny_l==true)&& (Flag_L==false)) Flag_H = true;
                pomocna_h=true;
                Flag_NORMAL =false;
                }
                break;
            case '\\': // musi zachovat priznak lomitka Flag_L
                   
                   Flag_NORMAL =false;
                   if((Flag_A ==true) || (Flag_U ==true)) {
                   if (Flag_S == true) Flag_S=false;
                   else Flag_S = true;
                   }
                break;
            case '"': // musi ignorovat vsetky znaky ktore su v uvodzovkach
            if (Flag_A == false){
                pomocny_l=false;
                Flag_NORMAL = true;
                if ((Flag_H==false) && (Flag_L==false)){
                    putchar(ch);
                    if (Flag_U==false)Flag_U = true;
                    else if (Flag_U==true)Flag_U = false;  
                }
            }  
            Flag_S=false;
                break;
            case '\'': // musi ignorovat vsetky znaky ktore su v apostrofoch
            if (Flag_U == false){
                pomocny_l=false;
                Flag_NORMAL = false;
            if ((Flag_H==false) && (Flag_L==false)){
                putchar('\'');
                if ((Flag_A==false)&& (Flag_S==false))Flag_A = true;
                else if ((Flag_A==true) && (Flag_S==false))Flag_A = false;  
            }
             }   
             Flag_S=false;
                break; 
            default: // tlacenie vsetkych znakou pokiak su splnene podmienky prizkakou
                Flag_NORMAL =true;
                if (ch !=('\n')) Flag_S=false;
                if ((pomocny_l ==true ) && (Flag_H == false) && ( Flag_L == false ) && ( Flag_U == false ) && ( Flag_A == false ) && (ch !=('\n'))){
                    putchar('/');
                }
                if ((pomocna_h==true)&& (Flag_H==false) && (Flag_L==false) && (Flag_A==false) && (ch !=('\n'))){
                  putchar('*');
                }
                pomocny_l=false;
                pomocna_h= false;
                if(ch !='\n')  Flag_S = false;
                if((Flag_U == false) && (Flag_A == false) && (Flag_L == false) && (Flag_H == false)) {
                    putchar(ch);}
                break;
        }
    }

    return 1;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        warning("pocet argumentov ma byt 1\n"); //ak je pocet argumentov mensi ako 1
        error_exit("momentalny pocet argumentov je: %d\n", argc); 
    }
    else if (argc > 2) {
        warning("pocet argumentov ma byt 1\n");//ak je poset argumentov viac ko 2 
    } 
    
        char *filename = argv[1];
        FILE *file = fopen(filename, "r");
        if (file == NULL) {
           error_exit("chyba citania zo suboru: %s\n",argv[1]); //chyba citania zo suboru
            return 1;
        }
        mazac(file);
        fclose(file); // Zavire subor
   

    return 0;
}
