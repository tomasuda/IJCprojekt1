// error.h
// Řešení IJC-DU1, příklad a),b) 20.3.2022
// Autor: Tomas Suda, FIT
// Přeloženo: gcc 11.4.0
// pracujem s prime a no-coment
#ifndef ERROR_H
#define ERROR_H



typedef enum {ERR_0=1, ERR_1,ERR_2} ERROR_CODES;

void warning(const char *fmt, ...) ;
void error_exit(const char *fmt, ...);
/* Funkce pro výpis varování */

#endif 