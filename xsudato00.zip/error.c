// error.c
// Řešení IJC-DU1, příklad a),b) 20.3.2022
// Autor: Tomas Suda, FIT
// Přeloženo: gcc 11.4.0
// pracujem s prime a no-coment

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include "error.h"


/* Funkce pro výpis varování */
void warning(const char *fmt, ...) {
    va_list args;
    fprintf(stderr, "Warning: ");
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
}

/* Funkce pro výpis chyby a ukončení programu */
void error_exit(const char *fmt, ...) {
    va_list args;
    fprintf(stderr, "Error: ");
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    exit(1);
}
 
